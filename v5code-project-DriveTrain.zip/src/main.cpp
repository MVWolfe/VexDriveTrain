/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Steven Wolfe                                     */
/*    Created:      Sun Feb 21 2021                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// FrontOuttake         motor         2               
// BackOuttake          motor         3               
// FrontLeftIntake      motor         9               
// FrontRightIntake     motor         10              
// FLMotor              motor         12              
// BLMotor              motor         11              
// BRMotor              motor         20              
// FRMotor              motor         19              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
   FrontOuttake.setVelocity(100,percent);
   BackOuttake.setVelocity(90,percent);
   FrontRightIntake.setVelocity(90,percent);
   FrontLeftIntake.setVelocity(90,percent);
  while (true){
   
   
  
    
 
    FLMotor.setVelocity((Controller1.Axis1.position(percent)) + (Controller1.Axis3.position(percent)) + (Controller1.Axis4.position(percent)),percent);
    BLMotor.setVelocity((Controller1.Axis1.position(percent)) + (Controller1.Axis3.position(percent)) - (Controller1.Axis4.position(percent)),percent);  
    FRMotor.setVelocity((Controller1.Axis1.position(percent)) - (Controller1.Axis3.position(percent)) + (Controller1.Axis4.position(percent)),percent);
    BRMotor.setVelocity((Controller1.Axis1.position(percent)) - (Controller1.Axis3.position(percent)) - (Controller1.Axis4.position(percent)),percent);

    FLMotor.spin(forward);
    BLMotor.spin(forward);
    FRMotor.spin(forward);
    BRMotor.spin(forward);

    FLMotor.setStopping(brake);
    BLMotor.setStopping(brake);
    FRMotor.setStopping(brake);
    BRMotor.setStopping(brake);


    if(Controller1.ButtonR2.pressing()){
      FrontLeftIntake.spin(forward);
      FrontRightIntake.spin(forward);
    } else if (Controller1.ButtonR1.pressing()){
      FrontLeftIntake.spin(reverse);
      FrontRightIntake.spin(reverse);
    } else if(Controller1.ButtonL1.pressing()){
      FrontOuttake.spin(forward);
      BackOuttake.spin(forward);  
    } else if(Controller1.ButtonL2.pressing()){
      FrontOuttake.spin(reverse);
      BackOuttake.spin(reverse);

    } 
    if(!(Controller1.ButtonR1.pressing()) && !(Controller1.ButtonR2.pressing())){
      FrontRightIntake.stop();
      FrontLeftIntake.stop();
    } 
    if(!(Controller1.ButtonL1.pressing()) && !(Controller1.ButtonL2.pressing())){
      FrontOuttake.stop();
      BackOuttake.stop();
    }
 
    }
  
  }
